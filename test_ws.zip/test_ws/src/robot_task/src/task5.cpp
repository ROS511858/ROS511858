#include <ros/ros.h>
#include <actionlib/client/simple_action_client.h>
#include <move_base_msgs/MoveBaseAction.h>

typedef actionlib::SimpleActionClient<move_base_msgs::MoveBaseAction> MoveBaseClient;

class Patrol {
public:
    Patrol() : ac_("move_base", true) {
        ROS_INFO("等待 move_base action server 启动...");
        ac_.waitForServer();
        ROS_INFO("move_base server 已启动");

        // 添加巡航目标点
        addGoal(1.26, 1.44, 0.0, 0.0, 0.0, 0.0, 1.0);
        addGoal(1.535, -0.295, 0.0, 0.0, 0.0, -0.696901553533, 0.717166803947);
        addGoal(-1.05, 1.45, 0.0, 0.0, 0.0, -0.707, 0.707);
        addGoal(-2.15, 1.35, 0.0, 0.0, 0.0, -0.707, 0.707);
        addGoal(-2.08, -1.69, 0.0, 0.0, 0.0, -0.707, 0.707);
        addGoal(-1.09, -1.85, 0.0, 0.0, 0.0, 0.0, 1.0);
        addGoal(0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0);
    }

    void run() {
        ros::Rate rate(1);
        while (ros::ok()) {
            for (size_t i = 0; i < goals_.size(); ++i) {
                sendGoal(goals_[i]);
            }
            ROS_INFO("完成一轮巡航，重新开始...");
            rate.sleep();
        }
    }

private:
    MoveBaseClient ac_;
    std::vector<move_base_msgs::MoveBaseGoal> goals_;

    void addGoal(double x, double y, double z, double ox, double oy, double oz, double ow) {
        move_base_msgs::MoveBaseGoal goal;
        goal.target_pose.header.frame_id = "map";
        goal.target_pose.header.stamp = ros::Time::now();
        goal.target_pose.pose.position.x = x;
        goal.target_pose.pose.position.y = y;
        goal.target_pose.pose.position.z = z;
        goal.target_pose.pose.orientation.x = ox;
        goal.target_pose.pose.orientation.y = oy;
        goal.target_pose.pose.orientation.z = oz;
        goal.target_pose.pose.orientation.w = ow;
        goals_.push_back(goal);
    }

    void sendGoal(const move_base_msgs::MoveBaseGoal& goal) {
        ROS_INFO("发送目标点： x=%.2f, y=%.2f", goal.target_pose.pose.position.x, goal.target_pose.pose.position.y);
        ac_.sendGoal(goal);
        ac_.waitForResult();
        ROS_INFO("已到达目标点\n");

        // 等待2秒后继续
        ros::Duration(2.0).sleep();
    }
};

int main(int argc, char** argv) {
    ros::init(argc, argv, "move_base_patrol");

    Patrol patrol;
    patrol.run();

    return 0;
}
