#include <ros/ros.h>
#include <geometry_msgs/Twist.h>
#include <nav_msgs/Odometry.h>
#include <cmath>

class MoveToGoal {
public:
    MoveToGoal() : nh_("~"), rate_(10), current_x_(0.0), current_y_(0.0), current_theta_(0.0), 
                   kp_linear_(0.5), kp_angular_(1.0) {

        // **创建 cmd_vel 话题的发布者**
        cmd_vel_pub_ = nh_.advertise<geometry_msgs::Twist>("/cmd_vel", 10);

        // **创建 odom 话题的订阅者**
        odom_sub_ = nh_.subscribe("/odom", 100, &MoveToGoal::odomCallback, this);

        // **等待 /odom 话题可用**
        waitForOdometry();
    }

    // **前进指定距离**
    void moveForward(double distance) {
        geometry_msgs::Twist cmd_vel;
        double start_x = current_x_;
        double start_y = current_y_;

        while (ros::ok()) {
            ros::spinOnce(); // **确保订阅回调生效**
            
            double dx = current_x_ - start_x;
            double dy = current_y_ - start_y;
            double traveled = std::sqrt(dx * dx + dy * dy);

            if (traveled >= distance - 0.03) {
                cmd_vel.linear.x = 0;
                cmd_vel_pub_.publish(cmd_vel);
                ROS_INFO("前进 %.2f 米完成！", distance);
                break;
            }

            cmd_vel.linear.x = std::min(kp_linear_ * (distance - traveled), 0.3);
            cmd_vel_pub_.publish(cmd_vel);
            rate_.sleep();
        }
    }

    // **旋转至目标角度**
    void rotate(double target_angle) {
        geometry_msgs::Twist cmd_vel;

        while (ros::ok()) {
            ros::spinOnce(); // **确保订阅回调生效**

            double angle_diff = normalizeAngle(target_angle - current_theta_);

            if (std::abs(angle_diff) < 0.03) {
                cmd_vel.angular.z = 0;
                cmd_vel_pub_.publish(cmd_vel);
                ROS_INFO("旋转到 %.2f 弧度完成！", target_angle);
                break;
            } else {
                cmd_vel.angular.z = std::min(0.5 * angle_diff, 0.5);
            }

            cmd_vel_pub_.publish(cmd_vel);
            rate_.sleep();
        }
    }

    // **获取当前角度（yaw 角）**
    double getCurrentTheta() const {
        return current_theta_;
    }

private:
    ros::NodeHandle nh_;
    ros::Publisher cmd_vel_pub_;
    ros::Subscriber odom_sub_;
    ros::Rate rate_;

    double current_x_, current_y_, current_theta_;
    double kp_linear_, kp_angular_;

    void odomCallback(const nav_msgs::Odometry::ConstPtr& msg) {
        current_x_ = msg->pose.pose.position.x;
        current_y_ = msg->pose.pose.position.y;
        current_theta_ = quaternionToEuler(msg->pose.pose.orientation);

        ROS_INFO("收到 Odom: x=%.2f, y=%.2f, theta=%.2f", current_x_, current_y_, current_theta_);
    }

    void waitForOdometry() {
        ROS_INFO("等待 /odom 话题...");
        while (ros::ok() && current_x_ == 0.0 && current_y_ == 0.0) {
            ros::spinOnce();
            ros::Duration(0.1).sleep();
        }
        ROS_INFO("/odom 话题已接收！");
    }

    double quaternionToEuler(const geometry_msgs::Quaternion& q) {
        double siny = 2 * (q.w * q.z + q.x * q.y);
        double cosy = 1 - 2 * (q.y * q.y + q.z * q.z);
        return std::atan2(siny, cosy);
    }

    double normalizeAngle(double angle) const {
        while (angle > M_PI) angle -= 2 * M_PI;
        while (angle < -M_PI) angle += 2 * M_PI;
        return angle;
    }
};

int main(int argc, char** argv) {
    ros::init(argc, argv, "move_to_goal");

    MoveToGoal controller;
    
    controller.moveForward(1.0);

    // **旋转 -90°（逆时针）**
    ROS_INFO("旋转 -90°（逆时针）");
    double current_angle = controller.getCurrentTheta();
    controller.rotate(current_angle - M_PI / 2);

    // **前进 3 米**
    controller.moveForward(3.0);

    // **旋转 +90°（顺时针）**
    ROS_INFO("旋转 +90°（顺时针）");
    current_angle = controller.getCurrentTheta();
    controller.rotate(current_angle + M_PI / 2);

    // **前进 1.5 米**
    controller.moveForward(1.5);

    // **旋转 +90°（逆时针）**
    ROS_INFO("旋转 +90°（逆时针）");
    current_angle = controller.getCurrentTheta();
    controller.rotate(current_angle + M_PI / 2);

    // **前进 3 米**
    controller.moveForward(3.0);

    // **旋转 -90°（逆时针）**
    ROS_INFO("旋转 -90°（逆时针）");
    current_angle = controller.getCurrentTheta();
    controller.rotate(current_angle - M_PI / 2);

    // **前进 0.5 米**
    controller.moveForward(0.5);

    return 0;
}
