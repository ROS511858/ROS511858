#include <ros/ros.h>
#include <sensor_msgs/LaserScan.h>
#include <geometry_msgs/Twist.h>
#include <cmath>
#include <limits>

class RadarParking {
public:
    // **在初始化列表中初始化 `nh_`，确保 ROS 句柄创建**
    RadarParking() : nh_("~"), rate_(10) {
        // **确保 ROS 时间系统已经初始化**
        if (!ros::Time::isValid()) {
            ROS_WARN("ROS 时间未初始化，等待时间系统启动...");
            ros::Time::waitForValid();
        }

        // **发布 /cmd_vel 话题**
        cmd_vel_pub_ = nh_.advertise<geometry_msgs::Twist>("/cmd_vel", 1);

        // **订阅 /scan 话题**
        scan_sub_ = nh_.subscribe("/scan", 1, &RadarParking::scanCallback, this);

        // **参数初始化**
        stop_threshold_ = 1.2;        
        forward_speed_ = 0.5;        
        stop_duration_case1_ = 3.0;  
        stop_duration_case2_ = 5.0;  
        ignore_duration_ = 2.0;
        ignoring_ = false;
        ignore_end_time_ = ros::Time(0); // 初始化为 0
    }

    void scanCallback(const sensor_msgs::LaserScan::ConstPtr& scan_msg) {
        latest_scan_ = *scan_msg; // **保存最新激光数据**
    }

    double getRangeAtAngle(const sensor_msgs::LaserScan& scan_msg, double angle_deg) {
        double angle_rad = angle_deg * M_PI / 180.0;
        if (angle_rad < scan_msg.angle_min || angle_rad > scan_msg.angle_max) {
            return std::numeric_limits<double>::infinity();
        }
        int index = static_cast<int>((angle_rad - scan_msg.angle_min) / scan_msg.angle_increment);
        index = std::max(0, std::min(index, static_cast<int>(scan_msg.ranges.size()) - 1));
        return scan_msg.ranges[index];
    }

    void run() {
        while (ros::ok()) {
            ros::spinOnce();

            if (latest_scan_.ranges.empty()) {
                rate_.sleep();
                continue;
            }

            if (ignoring_) {
                if (ros::Time::now() > ignore_end_time_) {
                    ignoring_ = false;
                } else {
                    geometry_msgs::Twist cmd_vel;
                    cmd_vel.linear.x = forward_speed_;
                    cmd_vel.angular.z = 0.0;
                    cmd_vel_pub_.publish(cmd_vel);
                    rate_.sleep();
                    continue;
                }
            }

            double left_dist = getRangeAtAngle(latest_scan_, 90);
            double right_dist = getRangeAtAngle(latest_scan_, 270);

            ROS_INFO("left_dist: %.3f   right_dist: %.3f", left_dist, right_dist);

            if ((0.9 < left_dist && left_dist < stop_threshold_) &&
                (0.9 < right_dist && right_dist < stop_threshold_)) {
                ROS_INFO("左右障碍均较近，触发停 3 秒 (L=%.2f, R=%.2f)", left_dist, right_dist);
                doStopAndIgnore(stop_duration_case1_, 2);
            } 
            else if (std::isinf(left_dist) && (1.1 < right_dist && right_dist < stop_threshold_)) {
                ROS_INFO("左侧测距=inf，右侧<1.2，触发停 5 秒 (L=inf, R=%.2f)", right_dist);
                doStopAndIgnore(stop_duration_case2_, 2);
            } 
            else if ((1.7 < right_dist && right_dist < 2.1) && (1.7 < left_dist && left_dist < 2.1)) {
                ROS_INFO("左右均 1.7~2.1m，触发停 5 秒 (L=%.2f, R=%.2f)", left_dist, right_dist);
                doStopAndIgnore(stop_duration_case2_, 5);
            } 
            else {
                geometry_msgs::Twist cmd_vel;
                cmd_vel.linear.x = forward_speed_;
                cmd_vel.angular.z = 0.0;
                cmd_vel_pub_.publish(cmd_vel);
            }

            rate_.sleep();
        }
    }

    void doStopAndIgnore(double stop_duration, double ignore_time) {
        geometry_msgs::Twist stop_cmd;
        stop_cmd.linear.x = 0.0;
        stop_cmd.angular.z = 0.0;
        cmd_vel_pub_.publish(stop_cmd);

        ros::Duration(stop_duration).sleep();

        ROS_INFO("忽略雷达检测 %.1f 秒，继续前进...", ignore_time);
        ignoring_ = true;
        ignore_end_time_ = ros::Time::now() + ros::Duration(ignore_time);
    }

private:
    ros::NodeHandle nh_;
    ros::Publisher cmd_vel_pub_;
    ros::Subscriber scan_sub_;
    sensor_msgs::LaserScan latest_scan_;
    ros::Rate rate_;

    bool ignoring_;
    ros::Time ignore_end_time_;

    double stop_threshold_;
    double forward_speed_;
    double stop_duration_case1_;
    double stop_duration_case2_;
    double ignore_duration_;
};

int main(int argc, char** argv) {
    ros::init(argc, argv, "radar_parking");

    RadarParking node;
    node.run();

    return 0;
}
